
from dotenv import load_dotenv,find_dotenv
from pymongo import MongoClient
import os as sys 
import json
import pprint

# path 
load_dotenv(find_dotenv())

Password_db = sys.environ.get("MONGODB_PWD")

connection_string = connection_string = f"mongodb+srv://deff4rkannet:{Password_db}@d3ffnet99.cxqex.mongodb.net/?retryWrites=true&w=majority&appName=D3ffNet99"

client = MongoClient(connection_string)

jeopardy_db = client.jeopardy_db
question = jeopardy_db.question

Printer = pprint.PrettyPrinter()

def fuzzy_matching():
    result = question.aggregate([
        {
            "$search" : {
                "index" : "language_search",
                "text" : {
                    "query" : "law",
                    "path" : "category",
                    "synonyms" : "mapping"
                }
            }
        }
    ])

    Printer.pprint(list(result))

# autocomplete
def autocomplete():
    result = question.aggregate([
        {
                "$search" : {
                "index" : "language_search",
                "autocomplete" : {
                    "query" : "health",
                    "path"  : "question",
                    "tokenOrder" : "sequential",
                    "fuzzy" : {}
                }
            }
        },
        {
            "$project" : {
                "_id" : 0,
                "question" : 1
            }
        }
        
    ])
    Printer.pprint(list(result))

def compound_queries() : 
    Result_compound = question.aggregate([
    {
        "$search": {
            "index": "language_search",
            "compound": {
                "must": [
                    {
                        "text": {
                            "query": ["COMPUTER", "CODING"],
                            "path": "category"
                        }
                    }
                ],
                "mustNot": [
                    {
                        "text": {
                            "query": "codes",
                            "path": "category"
                        }
                    }
                ],
                "should": [
                    {
                        "text": {
                            "query": "application",
                            "path": "answer"
                        }
                    }
                ]
            }
        }
    },
    {
        "$project": {
            "question": 1,
            "answer": 1,
            "category": 1,
            "score": {"$meta": "searchScore"}
        }
    }
])

    Printer.pprint(list(Result_compound))
compound_queries()

def relevance() : 
    # memperioritaskan pertanyaan yang muncul dibabak selanjutnya 
    result_relevance = question.aggregate([
        {
            "$search" : {
                "index" : "languange_search",
                "compound" : {
                    "must" : [
                        {
                            "text" : {
                                "query" : "GEOGRAPHY",
                                "path" : "category"
                            }
                        }
                    ],
                    "should" : [
                        {
                            "text" : {
                                "query" : "First Jeopardy",
                                "path" : "round",
                                "score" : {"boost": {"value" : 3.0}}
                            }
                        },
                        {
                            "text" : {
                                "query" : "Double Jeopardy",
                                "path" : "round",
                                "score" : {"boost" : {"value" : 2.0}}
                            }
                        }
                    ]
                }
            }
        },
        {
            "$project" : {
                "question" : 1,
                "answer" : 1,
                "category" : 1,
                "round" : 1,
                "score" : {"$meta" : "searchScore"}
            }
        },
        {
            "$limit" : 100
        }
    ])
    Printer.pprint(list(result_relevance))








# note
#Fuzzy searching memungkinkan pencarian yang dapat menangani 
# kesalahan ketik atau perbedaan kecil dalam kata-kata
                